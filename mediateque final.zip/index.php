<?php
include("./templates/common/header.php");
include("./templates/pdo.php");
include("./templates/affichage.php");
include("./templates/all.tpl.php");
include("./templates/common/footer.php");
?>